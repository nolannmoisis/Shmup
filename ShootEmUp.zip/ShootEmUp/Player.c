#include "Player.h"
#include "Scene.h"
#include "Common.h"

Player *Player_New(Scene *scene)
{
    Player *self = (Player *)calloc(1, sizeof(Player));
    AssertNew(self);

    Assets *assets = Scene_GetAssets(scene);

    self->texture = assets->player;
    self->scene = scene;
    self->position = Vec2_Set(1.0f, 4.5f);
    self->radius = 0.15f;
    self->state = PLAYER_FLYING;
    self->life = 10;
    self->delay = SHOOTINGDELAY;
    self->VitAng = ANGULARSPEED;
    self->nbrbullet = 0;
    self->GM = false;

    return self;
}

void Player_Delete(Player *self)
{
    if (!self) return;
    free(self);
}

void Player_Update(Player* self)
{
    // On r�cup�re des infos essentielles (communes � tout objet)
    Scene* scene = self->scene;
    Input* input = Scene_GetInput(scene);
    // Mise � jour de la vitesse en fonction de l'�tat des touches
    Vec2 velocity = Vec2_Set(input->hAxis, input->vAxis);
    // Mise � jour de la position
    self->position = Vec2_Add( // Nouvelle pos. = ancienne pos. +
        self->position, // (vitesse * temps �coul�)
        Vec2_Scale(velocity, Timer_GetDelta(g_time)));
    if (input->Godmode == true) {
        if (self->GM == false) {
            self->GM = true;
            printf("Godmode ON \n");
        }
        else {
            self->GM = false;
            printf("Godmode OFF \n");
        }
    }
    if (input->shootPressed == true) {
        Vec2 velocity = Vec2_Set(4.0f, 0.0f);
        Bullet* bullet = Bullet_New(
            self->scene, self->position, velocity, BULLET_PLAYER, 0);
        Scene_AppendBullet(self->scene, bullet);
    }
}

void Player_Render(Player *self)
{
    // On r�cup�re des infos essentielles (communes � tout objet)
    Scene* scene = self->scene;
    SDL_Renderer* renderer = Scene_GetRenderer(scene);
    Assets* assets = Scene_GetAssets(scene);
    Camera* camera = Scene_GetCamera(scene);
    // On calcule la position en pixels en fonction de la position
    // en tuiles, la taille de la fen�tre et la taille des textures.
    float scale = Camera_GetWorldToViewScale(camera);
    SDL_FRect dst = { 0 };
    // Changez 48 par une autre valeur pour grossir ou r�duire l'objet
    dst.h = 18 * PIX_TO_WORLD * scale;
    dst.w = 18 * PIX_TO_WORLD * scale;
    Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
    // Le point de r�f�rence est le centre de l'objet
    dst.x -= 0.50f * dst.w;
    dst.y -= 0.50f * dst.h;
    // On affiche en position dst (unit�s en pixels)
    SDL_RenderCopyExF(renderer, self->texture, NULL, &dst, 90.0f, NULL, 0);
    SDL_FRect hp = { 0 };
    hp.h = 6 * PIX_TO_WORLD * scale;
    hp.w = 14 * PIX_TO_WORLD * scale * self->life/10;
    Camera_WorldToView(camera, Vec2_Set(self->position.x, self->position.y-0.25), &hp.x, &hp.y);
    hp.x -= 0.50f * hp.w;
    hp.y -= 0.50f * hp.h;
    SDL_RenderCopyExF(renderer, self->scene->assets->hp, NULL, &hp, 0, NULL, 0);

}

void Player_Damage(Player *self, int damage)
{
    if (self->life >= 1) {
        self->life -= 1;
    }

    if (self->GM == true) {
        self->life = 10;
    }

    if(self->life == 0) {
        self->state = PLAYER_DYING;
        self->state = PLAYER_DEAD;
    }
    printf("Le potooship a mal\n");
}