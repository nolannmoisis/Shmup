#include "Enemy.h"
#include "Common.h"
#include "Scene.h"

Enemy *Enemy_New(Scene *scene, int type, Vec2 position)
{
    Enemy *self = (Enemy *)calloc(1, sizeof(Enemy));
    AssertNew(self);

    self->scene = scene;
    self->position = position;
    self->positionstart = position;
    self->type = type;
    self->state = ENEMY_FIRING;
    self->life = 100;
    self->lifestart = 100;
    self->delay = 0.1;
    self->delay2 = 0.1;
    self->delay3 = 0.1;
    self->delay4 = 0.1;
    self->direct = 1;
    self->firstshot = false;
    self->angletir = 0;
    self->velocity;
    self->delaymov = 0;
    self->circlebullet = 0;
    self->circlebullet2 = 0;
    self->slashbullet = 0;
    self->slashbullet2 = 0;
    self->slashdirec = 1;
    self->directx = 1;

    Assets *assets = Scene_GetAssets(self->scene);
    switch (type)
    {
    case ENEMY_FIGHTER:
        self->worldW = 64 * PIX_TO_WORLD;
        self->worldH = 64 * PIX_TO_WORLD;
        self->radius = 0.4f;
        self->texture = assets->fighter;
        break;

    case ENEMY_BOMBER:
        self->worldW = 64 * PIX_TO_WORLD;
        self->worldH = 64 * PIX_TO_WORLD;
        self->radius = 0.4f;
        self->texture = assets->bomber;
        break;

    case ENEMY_CRUISER:
        self->worldW = 64 * PIX_TO_WORLD;
        self->worldH = 64 * PIX_TO_WORLD;
        self->radius = 0.4f;
        self->texture = assets->cruiser;
        break;

    case ENEMY_COMMANDER:
        self->worldW = 64 * PIX_TO_WORLD;
        self->worldH = 64 * PIX_TO_WORLD;
        self->radius = 0.25f;
        self->texture = assets->commander;
        break;

    default:
        assert(false);
        break;

        return self;
    }
}

void Enemy_Delete(Enemy *self)
{
    if (!self) return;
    free(self);
}

void Enemy_Update(Enemy *self)
{
    Scene* scene = self->scene;
    switch (self->type)
    {
    case ENEMY_FIGHTER:
        if (self->positionstart.y < 4.5) {
            self->direct = -1;
        }
        self->position.y = 9 - self->positionstart.y - 1.0*sin(Timer_GetElapsed(g_time)*self->direct);
        if (self->state == ENEMY_FIRING) {
            self->delay -= Timer_GetDelta(g_time);
            if ((self->delay < 0.2) && (self->firstshot==false)) {
                self->firstshot = true;
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                Bullet* bullet = Bullet_New(
                    self->scene, self->position, velocity, BULLET_FIGHTER, 180);
                Scene_AppendBullet(self->scene, bullet);
            }
            if ((self->delay < 0) && (self->firstshot == true)) {
                self->firstshot = false;
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                Bullet* bullet = Bullet_New(
                    self->scene, self->position, velocity, BULLET_FIGHTER, 180);
                Scene_AppendBullet(self->scene, bullet);
                self->delay = 1.0;
            }
        }
        break;

    case ENEMY_BOMBER:
        if (self->positionstart.y < 4.5) {
            self->direct = -1;
        }
        self->position.y = 9 - self->positionstart.y - 0.7 * sin(Timer_GetElapsed(g_time) * self->direct);
        if (self->state == ENEMY_FIRING) {
            self->delay -= Timer_GetDelta(g_time);
            if (self->delay < 0) {
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_EXPLODE, 180);
                Scene_AppendBullet(self->scene, bullet);
                self->delay = 1.5;
            }
        }
        break;
    case ENEMY_CRUISER:
        if ((self->state == ENEMY_FIRING) || (self->state == ENEMY_FIRING2)) {
            self->delay -= Timer_GetDelta(g_time);
            if (self->delay < 0) {
                Vec2 AimPlayer = Vec2_Set(self->scene->player->position.x - self->position.x, self->scene->player->position.y - self->position.y);
                Vec2 AimPlayerNeutral = Vec2_Set(AimPlayer.x, 0.0);
                self->angletir = angle2vec(AimPlayer, AimPlayerNeutral);
                if (self->scene->player->position.y > self->position.y) {
                    self->angletir *= -1;
                }
                if (self->scene->player->position.x > self->position.x) {
                    self->directx = 0;
                    self->angletir *= -1;
                }
                else {
                    self->directx = 1;
                }
                Vec2 velocity = Vec2_Set(7.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_CRUISER, self->directx * 180 + self->angletir);
                Scene_AppendBullet(self->scene, bullet);
                self->delay = 0.5;
            }
        }
        if (self->state == ENEMY_FIRING2) {
            self->delay2 -= Timer_GetDelta(g_time);
            if (self->delay2 < 0) {
                Vec2 AimPlayer = Vec2_Set(self->scene->player->position.x - self->position.x, self->scene->player->position.y - self->position.y);
                Vec2 AimPlayerNeutral = Vec2_Set(AimPlayer.x, 0.0);
                self->angletir = angle2vec(AimPlayer, AimPlayerNeutral);
                if (self->direct==1) {
                    self->angletir *= -1;
                    self->direct = -1;
                }
                else {
                    self->direct = 1;
                }
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_CRUISER, 180 + self->angletir + 30*self->direct);
                Scene_AppendBullet(self->scene, bullet);
                self->delay2 = 0.1;
            }
        }
        
        break;
    case ENEMY_COMMANDER:
        if (self->state == ENEMY_FIRING) {
            self->position.y = 9 - self->positionstart.y - 1.5 * sin(Timer_GetElapsed(g_time) * self->direct);
            self->delay -= Timer_GetDelta(g_time);
            if (self->delay < 0) {
                Vec2 AimPlayer = Vec2_Set(self->scene->player->position.x - self->position.x, self->scene->player->position.y - self->position.y);
                Vec2 AimPlayerNeutral = Vec2_Set(AimPlayer.x, 0.0);
                self->angletir = angle2vec(AimPlayer, AimPlayerNeutral);
                if (self->scene->player->position.y > self->position.y) {
                    self->angletir *= -1;
                }
                if (self->scene->player->position.x > self->position.x) {
                    self->directx = 0;
                }
                else {
                    self->directx = 1;
                }
                Vec2 velocity = Vec2_Set(7.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_CRUISER, self->directx * 180 + self->angletir);
                Scene_AppendBullet(self->scene, bullet);
                self->delay = 0.5;
            }
        }
        if (self->state == ENEMY_FIRING2) {
            self->position.y = 4.5;
            self->delay2 -= Timer_GetDelta(g_time);
            if (self->circlebullet > 359) {
                self->circlebullet = 0;
            }
            if (self->delay2 < 0) {
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                if (self->circlebullet % 4 == 0) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, 8 * self->circlebullet + 20);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 1) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, -8 * self->circlebullet + 20);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 2) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, 180 + 8 * self->circlebullet + 20);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 3) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, 180 + -8 * self->circlebullet + 20);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
            }
        }
        if (self->state == ENEMY_FIRING3) {
            self->position.y = 4.5;
            self->delay -= Timer_GetDelta(g_time);
            self->delay2 -= Timer_GetDelta(g_time);
            self->delay3 -= Timer_GetDelta(g_time);
            if (self->circlebullet > 359) {
                self->circlebullet = 0;
                self->delay2 = 3;
            }
            if (self->delay2 < 0) {
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                if (self->circlebullet % 4 == 0) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, 8 * self->circlebullet +8);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 1) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, -8 * self->circlebullet +8);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 2) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, 180 + 8 * self->circlebullet +8);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 3) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, 180 + -8 * self->circlebullet +8);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay2 = SHOOTINGDELAY;
                }
            }
            if (self->slashbullet > 37) {
                self->slashbullet = 0;
                self->slashdirec = -self->slashdirec;
            }
            if (self->delay < 0) {
                Vec2 velocity = Vec2_Set(3.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER, self->slashdirec * 5 * self->slashbullet + 90* self->slashdirec);
                Scene_AppendBullet(self->scene, bullet);
                self->slashbullet++;
                self->delay = SHOOTINGDELAY;
            }
        }
        if (self->state == ENEMY_FIRING4) {
            self->position.y = 9 - self->positionstart.y - 1.5 * sin(Timer_GetElapsed(g_time) * self->direct);
            self->delay2 -= Timer_GetDelta(g_time);
            self->angletir = 0;
            if (self->delay2 < 0) {
                Vec2 velocity = Vec2_Set(5.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_EXPLODE, 180);
                Scene_AppendBullet(self->scene, bullet);
                self->delay2 = 0.5;
            }
        }
        if (self->state == ENEMY_FIRING5) {
            self->position.y = 4.5;
            self->delay -= Timer_GetDelta(g_time);
            self->delay2 -= Timer_GetDelta(g_time);
            self->delay3 -= Timer_GetDelta(g_time);
            self->delay4 -= Timer_GetDelta(g_time);
            if (self->slashbullet > 37) {
                self->slashbullet = 0;
                self->slashdirec = -self->slashdirec;
            }
            if (self->circlebullet > 359) {
                self->circlebullet = 0;
            }
            if (self->circlebullet2 > 359) {
                self->circlebullet2 = 0;
            }
            if (self->delay < 0) {
                Vec2 velocity = Vec2_Set(3.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, self->slashdirec * 5 * self->slashbullet + 90 * self->slashdirec);
                Scene_AppendBullet(self->scene, bullet);
                self->slashbullet++;
                self->delay = SHOOTINGDELAY;
            }
            if (self->delay2 < 0) {
                Vec2 velocity = Vec2_Set(3.0f, 0.0f);
                Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, self->slashdirec * -5 * self->slashbullet - 90 * self->slashdirec);
                Scene_AppendBullet(self->scene, bullet);
                self->slashbullet++;
                self->delay2 = SHOOTINGDELAY;
            }
            if(self->life<21) {
                Vec2 velocity = Vec2_Set(4.0f, 0.0f);
                if (self->circlebullet % 2 == 0) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, 8 * self->circlebullet + self->circlebullet);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay3 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 2 == 1) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, -8 * self->circlebullet + self->circlebullet);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet++;
                    self->delay3 = SHOOTINGDELAY;
                }
            }
            if (self->life<11) {
                Vec2 velocity = Vec2_Set(2.0f, 0.0f);
                if (self->circlebullet2 % 4 == 0) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, 8 * self->circlebullet2);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet2++;
                    self->delay4 = SHOOTINGDELAY;
                }
                if (self->circlebullet2 % 4 == 1) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, -8 * self->circlebullet2);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet2++;
                    self->delay4 = SHOOTINGDELAY;
                }
                if (self->circlebullet % 4 == 2) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, 180 + 8 * self->circlebullet2);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet2++;
                    self->delay4 = SHOOTINGDELAY;
                }
                if (self->circlebullet2 % 4 == 3) {
                    Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_COMMANDER3, 180 + -8 * self->circlebullet2);
                    Scene_AppendBullet(self->scene, bullet);
                    self->circlebullet2++;
                    self->delay4 = SHOOTINGDELAY;
                }
            }
        }
        break;
    }
}

void Enemy_Render(Enemy *self)
{
    // On r�cup�re des infos essentielles (communes � tout objet)
    Scene* scene = self->scene;
    SDL_Renderer* renderer = Scene_GetRenderer(scene);
    Assets* assets = Scene_GetAssets(scene);
    Camera* camera = Scene_GetCamera(scene);
    // On calcule la position en pixels en fonction de la position
    // en tuiles, la taille de la fen�tre et la taille des textures.
    float scale = Camera_GetWorldToViewScale(camera);
    SDL_FRect dst = { 0 };
    // Changez 48 par une autre valeur pour grossir ou r�duire l'objet
    dst.h = 25 * PIX_TO_WORLD * scale;
    dst.w = 25 * PIX_TO_WORLD * scale;
    Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
    // Le point de r�f�rence est le centre de l'objet
    dst.x -= 0.50f * dst.w;
    dst.y -= 0.50f * dst.h;
    // On affiche en position dst (unit�s en pixels)
    SDL_RenderCopyExF(
        renderer, self->texture, NULL, &dst, self->directx * 180 + 90.0f - self->angletir, NULL, 0);
    SDL_FRect hp = { 0 };
    hp.h = 6 * PIX_TO_WORLD * scale;
    hp.w = 14 * PIX_TO_WORLD * scale * self->life / self->lifestart;
    Camera_WorldToView(camera, Vec2_Set(self->position.x, self->position.y - 0.3), &hp.x, &hp.y);
    hp.x -= 0.50f * hp.w;
    hp.y -= 0.50f * hp.h;
    SDL_RenderCopyExF(renderer, self->scene->assets->hp, NULL, &hp, 0, NULL, 0);
}

void Enemy_Damage(Enemy* self, int damage)
{
    switch (self->type)
    {
    case ENEMY_FIGHTER:
        if (self->life == 100) {
            self->life = 3;
            self->lifestart = 3; 
        }
        if (self->life >= 1) {
            self->life -= 1;
        }
        if (self->life <= 0) {
            self->state = ENEMY_DEAD;
        }
        break;

    case ENEMY_BOMBER:
        if (self->life == 100) {
            self->life = 5;
            self->lifestart = 5;
        }
        if (self->life >= 1) {
            self->life -= 1;
        }
        if (self->life <= 0) {
            self->state = ENEMY_DEAD;
        }
        break;

    case ENEMY_CRUISER:
        if (self->life == 100) {
            self->life = 10;
            self->lifestart = 10;
        }
        if (self->life >= 1) {
            self->life -= 1;
        }
        if ((self->life < 5) && (self->state == ENEMY_FIRING)) {
            self->state = ENEMY_FIRING2;
        }
        if (self->life <= 0) {
            self->state = ENEMY_DEAD;
        }
        break;

    case ENEMY_COMMANDER:
        if (self->life == 100) {
            self->life = 90;
            self->lifestart = 90;
        }
        if (self->life >= 1) {
            self->life -= 1;
        }
        if ((self->life < 75) && (self->state == ENEMY_FIRING)) {
            self->state = ENEMY_FIRING4;
        }
        if ((self->life < 60) && (self->state == ENEMY_FIRING4)) {
            self->state = ENEMY_FIRING2;
        }
        if ((self->life < 45) && (self->state == ENEMY_FIRING2)) {
            self->state = ENEMY_FIRING3;
        }
        if ((self->life < 25) && (self->state == ENEMY_FIRING3)) {
            self->state = ENEMY_FIRING5;
        }
        if (self->life <= 0) {
            self->state = ENEMY_DEAD;
        }
        break;
    }
}
