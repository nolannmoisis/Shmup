#include "Math.h"

const Vec2 Vec2_Up = { 0.0f,  1.0f };
const Vec2 Vec2_Down = { 0.0f, -1.0f };
const Vec2 Vec2_Left = { -1.0f,  0.0f };
const Vec2 Vec2_Right = { 1.0f,  0.0f };
const Vec2 Vec2_Zero = { 0.0f,  0.0f };
const Vec2 Vec2_One = { 1.0f,  1.0f };

Vec2 Vec2_Set(float x, float y)
{
Vec2 v = { .x = x, .y = y };
return v;
}

Vec2 Vec2_Perp(Vec2 v)
{
return Vec2_Set(v.y, -v.x);
}


// TODO - Compl�tez le fichier

Vec2 Vec2_Add(Vec2 v1, Vec2 v2) {
Vec2 Vadd = { .x = v1.x + v2.x, .y = v1.y + v2.y };
return Vadd;
}


Vec2 Vec2_Sub(Vec2 v1, Vec2 v2) {
Vec2 Vsub = { .x = v1.x - v2.x, .y = v1.y - v2.y };
return Vsub;
}

Vec2 Vec2_Scale(Vec2 v, float s) {
Vec2 Vscale = { .x = v.x * s, .y = v.y * s };
return Vscale;
}

float Vec2_Length(Vec2 v)
{
return (sqrt(pow(v.x, 2) + pow(v.y, 2)));
}

float angle2vec(Vec2 v1, Vec2 v2)
{
	float norm1=Vec2_Length(v1);
	float norm2=Vec2_Length(v2);
	float scal= v1.x*v2.x + v1.y*v2.y ;
	float angle = acos(scal/(norm1*norm2));
	return (angle * 180 /M_PI);
}

Vec2 Vec2_Normalize(Vec2 v)
{
Vec2 Vnorm = { .x = v.x / Vec2_Length(v),.y = v.y / Vec2_Length(v) };
return Vnorm;
}

float Vec2_Distance(Vec2 v1, Vec2 v2)
{
return (sqrt(pow(v2.x - v1.x, 2) + pow(v2.y - v1.y, 2)));
}
