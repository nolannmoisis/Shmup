#include "Assets.h"

typedef struct TextureSpec_s
{
    SDL_Texture **ptr;
    char *path;
} TextureSpec;

Assets *Assets_New(SDL_Renderer *renderer)
{
    Assets *self = (Assets *)calloc(1, sizeof(Assets));
    AssertNew(self);

    // -------------------------------------------------------------------------
    // Chargement des textures

    TextureSpec texSpecs[] = {
        { &self->player,        "../Assets/Player/player.png"         },
        { &self->layers[0],     "../Assets/Background/layer_01.png"   },
        { &self->layers[1],     "../Assets/Background/layer_02.png"   },
        { &self->background,     "../Assets/Background/background.png"   },
        { &self->playerBullet,  "../Assets/Player/bullet_default.png" },
        { &self->fighter,       "../Assets/Enemy/fighter.png"         },
        { &self->commander,       "../Assets/Enemy/commander.png"         },
        { &self->cruiser,       "../Assets/Enemy/cruiser.png"         },
        { &self->fighterBullet, "../Assets/Enemy/fighter_bullet.png"  },
        { &self->cruiserBullet, "../Assets/Enemy/cruiser_bullet.png"  },
        { &self->commanderBullet, "../Assets/Enemy/commander_bullet.png"  },
        { &self->commanderBullet3, "../Assets/Enemy/commander_bullet3.png"  },
        { &self->PressSpace, "../Assets/Background/Press SPACE.png"},
        { &self->Gameover, "../Assets/Background/Gameover.png"},
        { &self->Youwin, "../Assets/Background/Youwin.png"},
        { &self->hprect, "../Assets/Player/hprect.png"},
        { &self->hp, "../Assets/Player/hp.png"},
        { &self->bomber,       "../Assets/Enemy/bomber.png"         }, 
    };
    int texSpecCount = sizeof(texSpecs) / sizeof(TextureSpec);

    for (int i = 0; i < texSpecCount; i++)
    {
        SDL_Texture **texPtr = texSpecs[i].ptr;
        char *path = texSpecs[i].path;

        *texPtr = IMG_LoadTexture(renderer, path);
        if (*texPtr == NULL)
        {
            printf("ERROR - Loading texture %s\n", path);
            printf("      - %s\n", SDL_GetError());
            assert(false);
            abort();
        }
    }

    return self;
}

void Assets_Delete(Assets *self)
{
    if (!self) return;

    // -------------------------------------------------------------------------
    // Lib�re les textures

    SDL_Texture **texPointers[] = {
        &self->player,
        &self->layers[0],
        &self->layers[1],
        &self->background,
        &self->playerBullet,
        &self->fighter,
        &self->fighterBullet,
        &self->cruiserBullet,
        &self->commanderBullet,
        &self->commanderBullet3,
        &self->PressSpace,
        &self->Youwin,
        &self->Gameover,
        &self->hp,
        &self->cruiser,
        &self->commander,
        &self->bomber,

    };
    int count = sizeof(texPointers) / sizeof(SDL_Texture **);

    for (int i = 0; i < count; i++)
    {
        if (*texPointers[i])
            SDL_DestroyTexture(*(texPointers[i]));
    }

    free(self);
}