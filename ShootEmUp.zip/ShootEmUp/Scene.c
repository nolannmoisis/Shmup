#include "Scene.h"

Scene *Scene_New(SDL_Renderer *renderer)
{
    Scene *self = (Scene *)calloc(1, sizeof(Scene));
    AssertNew(self);

    self->renderer = renderer;

    self->assets = Assets_New(renderer);
    self->camera = Camera_New(LOGICAL_WIDTH, LOGICAL_HEIGHT);
    self->input = Input_New();
    self->player = Player_New(self);
    self->waveIdx = 0;

    return self;
}

void Scene_Delete(Scene *self)
{
    if (!self) return;

    Assets_Delete(self->assets);
    Camera_Delete(self->camera);
    Input_Delete(self->input);
    Player_Delete(self->player);

    for (int i = 0; i < self->enemyCount; i++)
    {
        Enemy_Delete(self->enemies[i]);
        self->enemies[i] = NULL;
    }
    for (int i = 0; i < self->bulletCount; i++)
    {
        Bullet_Delete(self->bullets[i]);
        self->bullets[i] = NULL;
    }

    free(self);
}

void Scene_UpdateLevel(Scene *self)
{
    if (self->enemyCount > 0)
        return;

    if ((self->waveIdx == 0) && self->enemyCount == 0)
    {
        Enemy *enemy = Enemy_New(self, ENEMY_FIGHTER, Vec2_Set(15.0f, 6));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_FIGHTER, Vec2_Set(15.0f, 3));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 1) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(15.0f, 4.5f));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 2) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(15.0f, 4.5f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_FIGHTER, Vec2_Set(15.0f, 7));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_FIGHTER, Vec2_Set(15.0f, 2));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 3) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(15.0f, 6.0f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(15.0f, 3.0f));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 4) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_BOMBER, Vec2_Set(15.0f, 4.5f));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 5) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_BOMBER, Vec2_Set(15.0f, 6.0f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(11.0f, 4.5f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_BOMBER, Vec2_Set(15.0f, 3.0f));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 6) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_BOMBER, Vec2_Set(15.0f, 4.5f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(13.5f, 7.0f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_CRUISER, Vec2_Set(13.5f, 2.0f));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }

    if ((self->waveIdx == 7) && self->enemyCount == 0)
    {
        Enemy* enemy = Enemy_New(self, ENEMY_COMMANDER, Vec2_Set(15.0f, 4.5f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_BOMBER, Vec2_Set(13.5f, 8.0f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_BOMBER, Vec2_Set(13.5f, 1.0f));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_FIGHTER, Vec2_Set(15.0f, 6));
        Scene_AppendEnemy(self, enemy);
        enemy = Enemy_New(self, ENEMY_FIGHTER, Vec2_Set(15.0f, 3));
        Scene_AppendEnemy(self, enemy);
        self->waveIdx++;
    }
}

bool Menu_Update(Scene* self)
{
    Input_Update(self->input);
    return self->input->shootPressed;
}

bool GameOver_Update(Scene* self)
{
    Input_Update(self->input);
    return self->input->shootPressed;
}

bool Youwin_Update(Scene* self)
{
    Input_Update(self->input);
    return self->input->shootPressed;
}

bool Scene_Update(Scene *self)
{
    Player *player = self->player;
    // Met � jour les entr�es utilisateur
    Input_Update(self->input);
    // -------------------------------------------------------------------------
    // Met � jour les tirs

    int i = 0;
    while (i < self->bulletCount)
    {
        Bullet *bullet = self->bullets[i];
        bool removed = false;

        Bullet_Update(bullet);

        bool outOfBounds =
            (bullet->position.x < -1.0f) ||
            (bullet->position.x > 17.0f) ||
            (bullet->position.y < -1.0f) ||
            (bullet->position.y > 10.0f);

        if (outOfBounds)
        {
            // Supprime le tir
            Scene_RemoveBullet(self, i);
            removed = true;
            continue;
        }

        if (bullet->fromPlayer)
        {
            // Teste les collisions avec les ennemis
            for (int j = 0; j < self->enemyCount; j++)
            {
                Enemy *enemy = self->enemies[j];
                float dist = Vec2_Distance(bullet->position, enemy->position);
                if (dist < bullet->radius + enemy->radius)
                {
                    // Inflige des dommages � l'ennemi
                    Enemy_Damage(enemy, 1);

                    // Supprime le tir
                    Scene_RemoveBullet(self, i);
                    removed = true;
                    break;
                }
            }
        }
        else
        {
            // Teste la collision avec le joueur
            float dist = Vec2_Distance(bullet->position, self->player->position);
            if (dist < bullet->radius + player->radius)
            {
                // Inflige des dommages au joueur
                Player_Damage(player, 1);

                // Supprime le tir
                Scene_RemoveBullet(self, i);
                removed = true;
            }
        }

        // Passe au prochain tir
        if (removed == false)
        {
            i++;
        }
    }

    // -------------------------------------------------------------------------
    // Met � jour les ennemis

    i = 0;
    while (i < self->enemyCount)
    {
        Enemy *enemy = self->enemies[i];
        bool removed = false;

        Enemy_Update(enemy);

        if (enemy->state == ENEMY_DEAD)
        {
            // Supprime l'ennemi
            Scene_RemoveEnemy(self, i);
            removed = true;
        }

        // Passe au prochain ennemi
        if (removed == false)
        {
            i++;
        }
    }

    // -------------------------------------------------------------------------
    // Met � jour le joueur

    Player_Update(self->player);
    if (self->player->state==PLAYER_DEAD) {
        while (self->enemyCount>0)
        {
            Scene_RemoveEnemy(self, 0);
        }
        while (self->bulletCount>0)
        {
            Scene_RemoveBullet(self, 0);
        }
        while (true)
        {
            // Met � jour le temps
            Timer_Update(g_time);

            // Met � jour la sc�ne
            bool quitLoop = GameOver_Update(self);
            if (quitLoop)
                break;

            // Efface le rendu pr�c�dent
            SDL_SetRenderDrawColor(self->renderer, 0, 0, 0, 255);
            SDL_RenderClear(self->renderer);

            // Dessine la sc�ne
            Scene_Render(self);
            SDL_RenderCopy(self->renderer, self->assets->Gameover, NULL, NULL);

            // Affiche le nouveau rendu
            SDL_RenderPresent(self->renderer);
        }
        self->player = Player_New(self);
        self->waveIdx = 0;
    }
    if ((self->waveIdx == 8) && self->enemyCount == 0) {
        while (self->bulletCount > 0)
        {
            Scene_RemoveBullet(self, 0);
        }
        while (true)
        {
            // Met � jour le temps
            Timer_Update(g_time);

            // Met � jour la sc�ne
            bool quitLoop = Youwin_Update(self);
            if (quitLoop)
                break;

            // Efface le rendu pr�c�dent
            SDL_SetRenderDrawColor(self->renderer, 0, 0, 0, 255);
            SDL_RenderClear(self->renderer);

            // Dessine la sc�ne
            Scene_Render(self);
            SDL_RenderCopy(self->renderer, self->assets->Youwin, NULL, NULL);

            // Affiche le nouveau rendu
            SDL_RenderPresent(self->renderer);
        }
        self->player = Player_New(self);
        self->waveIdx = 0;
    }

    // -------------------------------------------------------------------------
    // Met � jour le niveau

    Scene_UpdateLevel(self);

    return self->input->quitPressed;
}

void Scene_Render(Scene *self)
{
    // Affichage du fond
    SDL_Renderer *renderer = Scene_GetRenderer(self);
    Assets *assets = Scene_GetAssets(self);

    SDL_FRect Xback;
    Xback.x = -20 * Timer_GetElapsed(g_time);
    Xback.y = 0;
    Xback.w = LOGICAL_WIDTH;
    Xback.h = LOGICAL_HEIGHT;
    while (Xback.x < -LOGICAL_WIDTH) Xback.x += LOGICAL_WIDTH*2;
    SDL_RenderCopyF(renderer, assets->background, NULL, &Xback);

    SDL_FRect Xbackbis;
    Xbackbis.x = LOGICAL_WIDTH - 20 * Timer_GetElapsed(g_time);
    Xbackbis.y = 0;
    Xbackbis.w = LOGICAL_WIDTH;
    Xbackbis.h = LOGICAL_HEIGHT;
    while (Xbackbis.x < -LOGICAL_WIDTH) Xbackbis.x += LOGICAL_WIDTH * 2;
    SDL_RenderCopyF(renderer, assets->background, NULL, &Xbackbis);

    SDL_FRect XposL0;
    XposL0.x = -50 * Timer_GetElapsed(g_time);
    XposL0.y = 0;
    XposL0.w = LOGICAL_WIDTH;
    XposL0.h = LOGICAL_HEIGHT;
    while (XposL0.x < -LOGICAL_WIDTH) XposL0.x += LOGICAL_WIDTH*2;
    SDL_RenderCopyF(renderer, assets->layers[0], NULL, &XposL0);

    SDL_FRect XposL0bis;
    XposL0bis.x = LOGICAL_WIDTH -50 * Timer_GetElapsed(g_time);
    XposL0bis.y = 0;
    XposL0bis.w = LOGICAL_WIDTH;
    XposL0bis.h = LOGICAL_HEIGHT;
    while (XposL0bis.x < -LOGICAL_WIDTH) XposL0bis.x += LOGICAL_WIDTH*2;
    SDL_RenderCopyF(renderer, assets->layers[0], NULL, &XposL0bis);

    SDL_FRect XposL1;
    XposL1.x = -70 * Timer_GetElapsed(g_time);
    XposL1.y = 0;
    XposL1.w = LOGICAL_WIDTH;
    XposL1.h = LOGICAL_HEIGHT;
    while (XposL1.x < -LOGICAL_WIDTH) XposL1.x += LOGICAL_WIDTH*2;
    SDL_RenderCopyF(renderer, assets->layers[1], NULL, &XposL1);

    SDL_FRect XposL1bis;
    XposL1bis.x = LOGICAL_WIDTH - 70 * Timer_GetElapsed(g_time);
    XposL1bis.y = 0;
    XposL1bis.w = LOGICAL_WIDTH;
    XposL1bis.h = LOGICAL_HEIGHT;
    while (XposL1bis.x < -LOGICAL_WIDTH) XposL1bis.x += LOGICAL_WIDTH*2;
    SDL_RenderCopyF(renderer, assets->layers[1], NULL, &XposL1bis);

    // Affichage des bullets
    int bulletCount = self->bulletCount;
    for (int i = 0; i < bulletCount; i++)
    {
        Bullet_Render(self->bullets[i]);
    }

    // Affichage des ennemis
    int enemyCount = self->enemyCount;
    for (int i = 0; i < enemyCount; i++)
    {
        Enemy_Render(self->enemies[i]);
    }

    // Affichage du joueur
    Player_Render(self->player);

}

void Scene_AppendObject(void *object, void **objectArray, int *count, int capacity)
{
    int index = *count;
    if (index >= capacity)
        return;

    if (objectArray[index] != NULL)
    {
        assert(false);
        abort();
    }

    objectArray[index] = object;
    (*count)++;
}

void Scene_AppendEnemy(Scene *self, Enemy *enemy)
{
    Scene_AppendObject(
        enemy,
        (void **)(self->enemies),
        &(self->enemyCount),
        ENEMY_CAPACITY
    );
}

void Scene_AppendBullet(Scene *self, Bullet *bullet)
{
    Scene_AppendObject(
        bullet,
        (void **)(self->bullets),
        &(self->bulletCount),
        BULLET_CAPACITY
    );
}

void Scene_RemoveObject(int index, void **objectArray, int *count)
{
    int lastIndex = *count - 1;
    assert(0 <= index && index < *count);

    if (objectArray[index] == NULL)
    {
        assert(false);
        abort();
    }

    if (index == lastIndex)
    {
        // Supprime le pointeur
        objectArray[index] = NULL;
    }
    else
    {
        // Remplace le pointeur par le dernier du tableau
        objectArray[index] = objectArray[lastIndex];
        objectArray[lastIndex] = NULL;
    }
    (*count)--;
}

void Scene_RemoveEnemy(Scene *self, int index)
{
    Enemy_Delete(self->enemies[index]);
    Scene_RemoveObject(index, (void **)(self->enemies), &(self->enemyCount));
}

void Scene_RemoveBullet(Scene *self, int index)
{
    Bullet_Delete(self->bullets[index]);
    Scene_RemoveObject(index, (void **)(self->bullets), &(self->bulletCount));
}
