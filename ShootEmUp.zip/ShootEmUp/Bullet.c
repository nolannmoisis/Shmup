#include "Bullet.h"
#include "Common.h"
#include "Scene.h"

Bullet *Bullet_New(Scene *scene, Vec2 position, Vec2 velocity, int type, float angle)
{
    Bullet *self = (Bullet *)calloc(1, sizeof(Bullet));
    AssertNew(self);

    self->position = position;
    self->velocity = velocity;
    self->type = type;
    self->angle = angle;
    self->scene = scene;
    self->traj = Vec2_Set(self->velocity.x * cos(self->angle * M_PI / 180) - self->velocity.y * sin(self->angle * M_PI / 180), self->velocity.x * sin(self->angle * M_PI / 180) + self->velocity.y * cos(self->angle * M_PI / 180));
    self->fromPlayer = false;

    Assets *assets = Scene_GetAssets(scene);
    switch (type)
    {
    case BULLET_FIGHTER:
        self->texture = assets->fighterBullet;
        self->worldW = 8 * PIX_TO_WORLD;
        self->worldH = 16 * PIX_TO_WORLD;
        self->radius = 0.05f;
        self->fromPlayer = false;
        break;

    case BULLET_EXPLODE:
        self->texture = assets->commanderBullet;
        self->worldW = 8 * PIX_TO_WORLD;
        self->worldH = 16 * PIX_TO_WORLD;
        self->radius = 0.05f;
        self->fromPlayer = false;
        break;

    case BULLET_CRUISER:
        self->texture = assets->cruiserBullet;
        self->worldW = 8 * PIX_TO_WORLD;
        self->worldH = 16 * PIX_TO_WORLD;
        self->radius = 0.05f;
        self->fromPlayer = false;
        break;

    case BULLET_COMMANDER:
        self->texture = assets->commanderBullet;
        self->worldW = 8 * PIX_TO_WORLD;
        self->worldH = 16 * PIX_TO_WORLD;
        self->radius = 0.005f;
        self->fromPlayer = false;
        break;

    case BULLET_COMMANDER3:
        self->texture = assets->commanderBullet3;
        self->worldW = 8 * PIX_TO_WORLD;
        self->worldH = 16 * PIX_TO_WORLD;
        self->radius = 0.005f;
        self->fromPlayer = false;
        break;

    case BULLET_PLAYER:
        self->texture = assets->playerBullet;
        self->worldW = 8 * PIX_TO_WORLD;
        self->worldH = 16 * PIX_TO_WORLD;
        self->radius = 0.005f;
        self->fromPlayer = true;
        break;
    }

    return self;
}

void Bullet_Delete(Bullet *self)
{
    if (!self) return;
    free(self);
}

void Bullet_Update(Bullet *self)
{
    self->position = Vec2_Add(self->position,Vec2_Scale(self->traj, Timer_GetDelta(g_time)));
    if ((self->type == BULLET_EXPLODE) && (self->position.x < 8)) {
        for (int i = 0; i < 18; i++) {
            Vec2 velocity = Vec2_Set(3.0f, 0.0f);
            Bullet* bullet = Bullet_New(self->scene, self->position, velocity, BULLET_FIGHTER, 20 * i);
            Scene_AppendBullet(self->scene, bullet);
        }
        self->position.x = -1.1;
    }
}

void Bullet_Render(Bullet* self)
{
    Scene* scene = self->scene;
    SDL_Renderer* renderer = Scene_GetRenderer(scene);
    Assets* assets = Scene_GetAssets(scene);
    Camera* camera = Scene_GetCamera(scene);
    float scale = Camera_GetWorldToViewScale(camera);
    SDL_FRect dst = { 0 };
    switch (self->type)
    {
    case BULLET_FIGHTER:
        dst.h = 16 * PIX_TO_WORLD * scale;
        dst.w = 16 * PIX_TO_WORLD * scale;
        Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
        // Le point de r�f�rence est le centre de l'objet
        dst.x -= 0.50f * dst.w;
        dst.y -= 0.50f * dst.h;
        // On affiche en position dst (unit�s en pixels)
        SDL_RenderCopyExF(
            renderer, self->texture, NULL, &dst, 90 - self->angle, NULL, 0);
        break;

    case BULLET_EXPLODE:
        dst.h = 16 * PIX_TO_WORLD * scale;
        dst.w = 16 * PIX_TO_WORLD * scale;
        Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
        // Le point de r�f�rence est le centre de l'objet
        dst.x -= 0.50f * dst.w;
        dst.y -= 0.50f * dst.h;
        // On affiche en position dst (unit�s en pixels)
        SDL_RenderCopyExF(
            renderer, self->texture, NULL, &dst, 90 - self->angle, NULL, 0);
        break;

    case BULLET_CRUISER:
        dst.h = 16 * PIX_TO_WORLD * scale;
        dst.w = 16 * PIX_TO_WORLD * scale;
        Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
        // Le point de r�f�rence est le centre de l'objet
        dst.x -= 0.50f * dst.w;
        dst.y -= 0.50f * dst.h;
        // On affiche en position dst (unit�s en pixels)
        SDL_RenderCopyExF(
            renderer, self->texture, NULL, &dst, 90 - self->angle, NULL, 0);
        break;

    case BULLET_COMMANDER:
        dst.h = 8 * PIX_TO_WORLD * scale;
        dst.w = 8 * PIX_TO_WORLD * scale;
        Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
        // Le point de r�f�rence est le centre de l'objet
        dst.x -= 0.50f * dst.w;
        dst.y -= 0.50f * dst.h;
        // On affiche en position dst (unit�s en pixels)
        SDL_RenderCopyExF(
            renderer, self->texture, NULL, &dst, 90 - self->angle, NULL, 0);
        break;

    case BULLET_COMMANDER3:
        dst.h = 8 * PIX_TO_WORLD * scale;
        dst.w = 8 * PIX_TO_WORLD * scale;
        Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
        // Le point de r�f�rence est le centre de l'objet
        dst.x -= 0.50f * dst.w;
        dst.y -= 0.50f * dst.h;
        // On affiche en position dst (unit�s en pixels)
        SDL_RenderCopyExF(
            renderer, self->texture, NULL, &dst, 90 - self->angle, NULL, 0);
        break;

    case BULLET_PLAYER:
        // Changez 48 par une autre valeur pour grossir ou r�duire l'objet
        dst.h = 8 * PIX_TO_WORLD * scale;
        dst.w = 8 * PIX_TO_WORLD * scale;
        Camera_WorldToView(camera, self->position, &dst.x, &dst.y);
        // Le point de r�f�rence est le centre de l'objet
        dst.x -= 0.50f * dst.w;
        dst.y -= 0.50f * dst.h;
        // On affiche en position dst (unit�s en pixels)
        SDL_RenderCopyExF(
            renderer, self->texture, NULL, &dst, 90 - self->angle, NULL, 0);
        break;
    }
}